TraduccionCamposWebTx_SAC = {
    "ID op." : "NROOPERACION",
    "Site" : "NROCOMERCIO",
    "Monto" : "MONTO",
    "Cuotas" : "CUOTAS",
    "Titular" : "NOMBREENTARJETA",
    "e-mail" : "EMAILCLIENTE"
}
