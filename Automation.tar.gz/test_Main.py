# -*- coding: utf-8 -*-
from selenium import webdriver
from pages.TemplateCompraSimple import TemplateCompraSimple
from pages.TemplateCompraDistribuida import TemplateCompraDistribuida
from pages.TemplateTxConAgregador import TemplateTxConAgregador
from pages.Validation import Validation
from pages.SACLogin import SACLogin
from pages.SACInicio import SACInicio
from pages.SAC import SACTxHistory
from pages.ConfirmTx import  ConfirmTx
from Data import *
from tools import TraduccionCamposWebTx_SAC
from nose2 import *
from nose2.tools.params import params
import os
from settings import *
import unittest
from hamcrest import *
import QAPI

class BaseTest:

    def fillTemplate(self, template, fillingData):

        for attr in [attr for attr in template.__dict__.keys() if attr in fillingData.keys()]:
            getattr(template, attr).fill(fillingData[attr])

    def setUp(self):
        self.baseURL = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["baseURL"]
        self.port = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["port"]
        if os.getenv("DRIVER", defaultDriver) == "phantomjs":
            self.driver = webdriver.PhantomJS()
        else:
            self.driver = webdriver.Chrome("/home/juan/Automation/chromedriver")

    def tearDown(self):
        #self.driver.quit()
        pass

    def runTx(self, txData, validationData, txTemplate):
        template = txTemplate(self.driver, self.baseURL, self.port)
        self.fillTemplate(template, txData)
        template.SUBMIT.click()

        validation = Validation(self.driver, txData["MEDIODEPAGO"])
        satisfactoryTxData = {}
        if validation.wasApproved():
            self.fillTemplate(validation, validationData)
            validation.SUBMIT.click()
            if validationData["NROTARJETA"].startswith("5"):
                confirmTx = ConfirmTx(self.driver)
                confirmTx.CONFIRMAR.click()

            #It verifies the tx data that is displayed on screen when it was satisfactory.
            satisfactoryTxData = validation.getSatisfactoryTxData(self.driver, txData["MEDIODEPAGO"],
                                                                  validationData["NROTARJETA"])
            for key in list(set(txData.keys() + validationData.keys()).intersection(satisfactoryTxData.keys())):
                assert_that(txData[key] if txData.has_key(key) else validationData[key],
                            equal_to(satisfactoryTxData[key]))

        return (validation.wasApproved(), satisfactoryTxData)

    def assertTxInSAC(self, sacTxHistory, txData, validationData, txId, isFatherTx=False):
        sacTxData = sacTxHistory.getTx(txId, isFatherTx)

        for key in sacTxData:
            assert_that(txData[key] if txData.has_key(key) else validationData[key],
                        equal_to_ignoring_case(sacTxData[key]))

    def assertSubtxsByPercentaje(self, sacTxHistory, txData, distributedTxId):
        """
        :param distributedTxId:
        Verify if each subTx from distributed one is right, according to its amount, installments and siteId.
        """
        distributedTxData = sacTxHistory.getDistributedTx(distributedTxId)
        distributedTx, simpleTxs = distributedTxData[1], distributedTxData[2:]

        amountOfDistributedTx = str(int(txData["MONTO"]) * 10 / 100)
        numberOfSimpleTxs = len(txData["SITEDIST"].split("#"))
        amountOfSimpleTxs = str(((int(txData["MONTO"])) - int(amountOfDistributedTx)) / numberOfSimpleTxs)

        # 1) Assert single tx whose site is father site
        assert_that(distributedTx["NROCOMERCIO"], equal_to_ignoring_case(txData["NROCOMERCIO"]))
        assert_that(distributedTx["MONTO"], equal_to_ignoring_case(amountOfDistributedTx))
        assert_that(distributedTx["CUOTAS"], equal_to_ignoring_case(txData["CUOTAS"]))

        # 2) Assert each simple tx whose sites are subsites
        for i in range(len(simpleTxs)):
            assert_that(simpleTxs[i]["NROCOMERCIO"], equal_to_ignoring_case(txData["SITEDIST"].split("#")[i]))
            assert_that(simpleTxs[i]["MONTO"], equal_to_ignoring_case(amountOfSimpleTxs))
            assert_that(simpleTxs[i]["CUOTAS"], equal_to_ignoring_case(txData["CUOTASDIST"].split("#")[i]))

    def assertSubtxsByAmount(self, sacTxHistory, txData, distributedTxId):
        """
        :param distributedTxId:
        Verify if each subTx from distributed one is right, according to its amount, installments and siteId.
        """

        #TODO: currently, it suposses that you're on SACTxHistory webpage
        subTxs = sacTxHistory.getDistributedTx(distributedTxId)[
                 1:]  # because the first one is the distributedTx, so we take remaining ones

        for i in range(len(subTxs)):
            assert_that(subTxs[i]["NROCOMERCIO"], equal_to_ignoring_case(txData["SITEDIST"].split("#")[i]))
            assert_that(subTxs[i]["MONTO"], equal_to_ignoring_case(txData["IMPDIST"].split("#")[i]))
            assert_that(subTxs[i]["CUOTAS"], equal_to_ignoring_case(txData["CUOTASDIST"].split("#")[i]))

class TxDistribuida(unittest.TestCase, BaseTest):

    def setUp(self):
        self.baseURL = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["baseURL"]
        self.port = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["port"]
        if os.getenv("DRIVER", defaultDriver) == "phantomjs":
            self.driver = webdriver.PhantomJS()
        else:
            self.driver = webdriver.Chrome("/home/juan/Automation/chromedriver")

    def tearDown(self):
        #self.driver.quit()
        pass

    def beforeTest_DistribuidaPorMonto(self, txData):
        QAPI.unsetCS(txData["NROCOMERCIO"])
        QAPI.unsetDistributedTxByPercentage(txData["NROCOMERCIO"])
        QAPI.deleteSubsites(txData["NROCOMERCIO"])
        QAPI.addSubsites(txData["NROCOMERCIO"], txData["SITEDIST"].replace("#", ","))

    def beforeTest_DistribuidaPorPorcentaje(self, txData):
        QAPI.unsetCS(txData["NROCOMERCIO"])
        QAPI.deleteSubsites(txData["NROCOMERCIO"])
        QAPI.addSubsites(txData["NROCOMERCIO"], txData["SITEDIST"].replace("#", ","))
        QAPI.setDistributedTxByPercentage(txData["NROCOMERCIO"])

    @params(
        (compraDistribuidaVisaData, validationVisaData, True),
    )
    def test_DistribuidaPorPorcentaje(self, txData, validationData, expectedResult):

        self.beforeTest_DistribuidaPorPorcentaje(txData)
        txResult, satisfactoryTxData = self.runTx(txData, validationData, TemplateCompraDistribuida)
        assert_that (txResult, expectedResult)

        sacLogin = SACLogin(self.driver)
        sacLogin.login()
        sacInicio = SACInicio(self.driver)
        sacInicio.consulta.click()
        sacTxHistory = SACTxHistory(self.driver)

        self.assertTxInSAC(sacTxHistory, txData, validationData, satisfactoryTxData["NROOPERACION"], isFatherTx=True)
        self.assertSubtxsByPercentaje(sacTxHistory, txData, satisfactoryTxData["NROOPERACION"])

    @params(
        (compraDistribuidaVisaData, validationVisaData, True),
        (compraDistribuidaMastercardData, validationMastercardData, True),
    )
    def test_DistribuidaPorMonto_Approved(self, txData, validationData, expectedResult):
        self.beforeTest_DistribuidaPorMonto(txData)
        txResult, satisfactoryTxData = self.runTx(txData, validationData, TemplateCompraDistribuida)
        assert_that (txResult, expectedResult)

        sacLogin = SACLogin(self.driver)
        sacLogin.login()
        sacInicio = SACInicio(self.driver)
        sacInicio.consulta.click()
        sacTxHistory = SACTxHistory(self.driver)

        self.assertTxInSAC(sacTxHistory, txData, validationData, satisfactoryTxData["NROOPERACION"], isFatherTx=True)
        self.assertSubtxsByAmount(sacTxHistory, txData, satisfactoryTxData["NROOPERACION"])

class TxSimple(unittest.TestCase, BaseTest):

    def setUp(self):
        self.baseURL = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["baseURL"]
        self.port = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["port"]
        if os.getenv("DRIVER", defaultDriver) == "phantomjs":
            self.driver = webdriver.PhantomJS()
        else:
            self.driver = webdriver.Chrome("/home/juan/Automation/chromedriver")

    def tearDown(self):
        #self.driver.quit()
        pass

    @params(
        (compraSimpleVisaData, validationVisaData, True),
        (compraSimpleMastercardData, validationMastercardData, True),
        (compraSimpleNativaVisaData, validationNativaVisaData, True),
        (compraSimpleNativaMastercardData, validationNativaMastercardData, True),
    )

    def test_Approved(self, txData, validationData, expectedResult):
        txResult, satisfactoryTxData = self.runTx(txData, validationData, TemplateCompraSimple)
        assert_that(txResult, expectedResult)
        sacLogin = SACLogin(self.driver)
        sacLogin.login()
        sacInicio = SACInicio(self.driver)
        sacInicio.consulta.click()
        sacTxHistory = SACTxHistory(self.driver)
        self.assertTxInSAC(sacTxHistory, txData, validationData, satisfactoryTxData["NROOPERACION"])

class TxSimpleConAgregador(BaseTest, unittest.TestCase):

    @params(
        (compraSimpleConAgregadorData, validationVisaData, True),
    )
    def test_Approved(self, txData, validationData, expectedResult):
        template = TemplateTxConAgregador(self.driver, self.baseURL, self.port)
        self.fillTemplate(template, txData)
        template.SUBMIT.click()
        validation = Validation(self.driver, txData["MEDIODEPAGO"])
        if validation.wasApproved():
            self.fillTemplate(validation, validationData)
            validation.SUBMIT.click()
            if validationData["NROTARJETA"].startswith("5"):
                confirmTx = ConfirmTx(self.driver)
                confirmTx.CONFIRMAR.click()
            # It verifies the tx data that is displayed on screen when it was satisfactory.
            satisfactoryTxData = validation.getSatisfactoryTxData(self.driver, txData["MEDIODEPAGO"],
                                                                  validationData["NROTARJETA"])
            for key in list(set(txData.keys() + validationData.keys()).intersection(satisfactoryTxData.keys())):
                assert_that(txData[key] if txData.has_key(key) else validationData[key],
                            equal_to(satisfactoryTxData[key]))
            # It verifies that satisfactory Tx was replicated on SAC.
            sacLogin = SACLogin(self.driver)
            sacLogin.login()
            sacInicio = SACInicio(self.driver)
            sacInicio.consulta.click()
            sacTxHistory = SACTxHistory(self.driver)

            sacTxData = sacTxHistory.getTx(satisfactoryTxData["NROOPERACION"])

            for key in sacTxData:
                assert_that(txData[key] if txData.has_key(key) else validationData[key],
                            equal_to_ignoring_case(sacTxData[key]))

        # It verifies that Tx was satisfactory or not, considering the expectedResult
        assert (validation.wasApproved() == expectedResult)