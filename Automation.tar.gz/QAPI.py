import os
import requests
from settings import *


baseURL = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["QAPI"]["baseURL"]
port = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["QAPI"]["port"]
coreTxBaseURL = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["coreTx"]["baseURL"]
coreTxPort = environments[os.getenv("ENVIRONMENT", defaultEnvironment)]["coreTx"]["port"]

def setDistributedTxByPercentage(siteId):
    response = requests.post(("http://{}:{}/sites/porcentaje").format(baseURL, port),
                  json={
                        "site": siteId
                        })

    if response.ok: replicate(siteId)

def unsetDistributedTxByPercentage(siteId):
    response = requests.delete(("http://{}:{}/sites/porcentaje").format(baseURL, port),
                             json={
                                 "site": siteId
                             })

    if response.ok: replicate(siteId)

def addSubsites(siteId, subsitesIds):
    response = requests.post(("http://{}:{}/sites/subsites").format(baseURL, port),
                json ={
                    "site": siteId,
                    "subsites": subsitesIds
                })

    if response.ok: replicate(siteId)

def deleteSubsites(siteId, subsitesIds=""):
    response = requests.delete(("http://{}:{}/sites/subsites").format(baseURL, port),
                             json={
                                 "site": siteId,
                                 "subsites": subsitesIds
                             })
    if response.ok: replicate(siteId)

def unsetCS(siteId):
    response = requests.delete(("http://{}:{}/sites/cs").format(baseURL, port),
                               json={
                                   "site": siteId
                               })
    if response.ok: replicate(siteId)

def replicate (siteId):
    replicationResponse = requests.get(("http://{}:{}/replication/site/{}").format(coreTxBaseURL, coreTxPort, siteId))