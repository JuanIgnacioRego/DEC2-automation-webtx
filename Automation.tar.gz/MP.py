# -*- coding: utf-8 -*-
#TODO
"""
1) Build a better Product.print(). Look into __str__ method
2) Add to the previous method a reference to website, e.g.: "Onfut - B5000- $)"
3) Heritate from a  class "Site"
"""

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time

class Product:

    def __init__(self, name, price, old_price = "", image_link = ""):
        self.name = name
        self.price = price
        self.old_price = old_price
        self.image_link = image_link

    def stdout(self):
        print ("{}) {} - {}".format(self.__class__.__name__, self.name, self.price))

class MercadoLibre:
    def __init__(self, product_link):
        self.product_link = product_link
        driver.get(product_link)
        name = driver.find_element_by_xpath ("//h1[@class='item-title__primary ']").text
        price = driver.find_element_by_xpath("//span[@class='price-tag-fraction']").text
        self.my_product = Product(name, price)

class Sismo:

    def __init__(self, product_link):
        self.product_link = product_link
        driver.get(product_link)
        name = driver.find_element_by_xpath("//h1[@class='title border']").text
        price = driver.find_element_by_xpath(".//span[@class='ch-price price']").text

        self.my_product = Product(name, price)

class LoriaSkateShop:

    def __init__(self, product_link):
        driver.get(product_link)
        name = driver.find_element_by_xpath("//h2[@itemprop='name']").text
        price = driver.find_element_by_id("our_price_display").text
        self.my_product = Product (name, price)

class Onfut(Product):

     def __init__(self, product_link):
         self.product_link = product_link
         driver.get(product_link)
         name = driver.find_element_by_xpath("//span[@class='h1']").text
         if len(driver.find_elements_by_xpath("//span[@class='special-price']/span[@class='price']")) >0:
             price = driver.find_element_by_xpath("//span[@class='special-price']/span[@class='price']").text
         else:
             price = driver.find_element_by_xpath("//span[@class='regular-price']/span[@class='price']").text

         self.my_product = Product(name, price)


if __name__ == "__main__":
    #driver = webdriver.PhantomJS("/home/juan/Automation/phantomjs")

    chrome_options = Options()
    chrome_options.add_argument("--headless")
    driver = webdriver.Chrome("/home/juan/Automation/chromedriver", chrome_options = chrome_options)
    links = [

        (Onfut ("http://www.onfutshop.com/hombre/diadora/camaro.html")),
        (Onfut ("http://www.onfutshop.com/hombre/diadora/b5000.html")),
        (Sismo("https://www.emerica.com.ar/zapatillas-de-skate-emerica-westgate-mid-vulc-brown-765687210xJM")),
        (Sismo ("https://www.sismoapparel.com/campera-sismo-atlas-verde-772462517xJM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-681348197-molinillo-de-mix-de-especies-italianas-picante-_JM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-684671692-pack-condimentos-cannamela-x-3-unid-_JM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-690269748-molinillo-sazonador-dani-sabor-italia-40gr-espana-_JM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-607330247-nuez-moscada-san-giorgio-con-molinillo-vto-2018-oferta-_JM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-681809374-natural-mix-de-especias-para-pollo-molinillo-50-gr-sudafrica-_JM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-620599093-peperoncino-trozado-con-molinillo-alimentari-20gr-en-palermo-_JM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-690270015-molinillo-sazonador-dani-sabor-marruecos-40gr-espana-_JM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-692261840-mini-pimentero-molinillo-ad-hoc-acero-inox-pimienta-sal-_JM")),
        (MercadoLibre ("https://articulo.mercadolibre.com.ar/MLA-684673850-condimentos-cannamela-x-3-unidades-_JM")),
        (LoriaSkateShop("https://tienda.loria.com.ar/hombres/966-fura.html#/77-color-uva/94-talle-7")),
        (LoriaSkateShop("https://tienda.loria.com.ar/hombres/1004-griffin.html#/47-color-azul/94-talle-7")),
        (LoriaSkateShop("https://tienda.loria.com.ar/hombres/966-fura.html")),
        (LoriaSkateShop("https://tienda.loria.com.ar/hombres/837-pico.html"))
        #SPYLTD

    ]

    for link in links:
            new_product = link.my_product
            new_product.stdout()
