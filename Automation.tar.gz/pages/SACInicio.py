from pages.BasePage import BasePage

class SACInicio(BasePage):

    def __init__(self, driver):
        BasePage.__init__(self,driver)
