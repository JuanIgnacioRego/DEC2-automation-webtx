from pages.BasePage import BasePage

class ConfirmTx(BasePage):

    def __init__(self, driver):
        BasePage.__init__(self,driver)